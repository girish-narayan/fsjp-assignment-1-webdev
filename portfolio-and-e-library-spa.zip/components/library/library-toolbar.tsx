import { Search, X } from 'lucide-react'
import { CATEGORIES, type Category } from './library-data'

type LibraryToolbarProps = {
  query: string
  onQueryChange: (value: string) => void
  category: Category | 'All'
  onCategoryChange: (value: Category | 'All') => void
  resultCount: number
}

export function LibraryToolbar({ query, onQueryChange, category, onCategoryChange, resultCount }: LibraryToolbarProps) {
  const options: (Category | 'All')[] = ['All', ...CATEGORIES]
  return (
    <div className="flex flex-col gap-4">
      <div className="relative">
        <label htmlFor="book-search" className="sr-only">
          Search books by title or author
        </label>
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
        <input
          id="book-search"
          type="search"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search by title or author..."
          className="w-full rounded-md border border-input bg-background py-2.5 pl-10 pr-10 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
        />
        {query && (
          <button
            type="button"
            onClick={() => onQueryChange('')}
            aria-label="Clear search"
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        )}
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div role="group" aria-label="Filter by category" className="flex flex-wrap gap-2">
          {options.map((option) => {
            const active = option === category
            return (
              <button
                key={option}
                type="button"
                aria-pressed={active}
                onClick={() => onCategoryChange(option)}
                className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                  active
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-border bg-background text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                {option}
              </button>
            )
          })}
        </div>
        <p className="font-mono text-xs text-muted-foreground" aria-live="polite">
          {resultCount} {resultCount === 1 ? 'book' : 'books'} found
        </p>
      </div>
    </div>
  )
}
