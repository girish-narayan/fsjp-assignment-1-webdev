'use client'

import { useMemo, useState } from 'react'
import { BookMarked, Library } from 'lucide-react'
import { BOOKS, type Book, type Category, type LibraryTab, type Review } from './library-data'
import { LibraryToolbar } from './library-toolbar'
import { LibraryTabs } from './library-tabs'
import { BookGrid } from './book-grid'
import { AcademicResources } from './academic-resources'
import { BookDetailsModal } from './book-details-modal'
import { ReadingListDrawer } from './reading-list-drawer'
import { Toast, type ToastMessage } from './toast'

export function LibrarySPA() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<Category | 'All'>('All')
  const [activeTab, setActiveTab] = useState<LibraryTab>('all')
  const [borrowedIds, setBorrowedIds] = useState<string[]>([])
  const [readingListIds, setReadingListIds] = useState<string[]>([])
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [reviews, setReviews] = useState<Record<string, Review[]>>({})
  const [toast, setToast] = useState<ToastMessage | null>(null)

  const showToast = (message: string, tone: ToastMessage['tone'] = 'success') =>
    setToast({ id: Date.now(), message, tone })

  const filteredBooks = useMemo(() => {
    const q = query.trim().toLowerCase()
    return BOOKS.filter((book) => {
      const matchesCategory = category === 'All' || book.category === category
      const matchesQuery = !q || book.title.toLowerCase().includes(q) || book.author.toLowerCase().includes(q)
      return matchesCategory && matchesQuery
    })
  }, [query, category])

  const borrowedBooks = BOOKS.filter((book) => borrowedIds.includes(book.id))
  const readingListBooks = BOOKS.filter((book) => readingListIds.includes(book.id))
  const selectedBook = BOOKS.find((book) => book.id === selectedBookId) ?? null

  const toggleBorrow = (book: Book) => {
    if (borrowedIds.includes(book.id)) {
      setBorrowedIds((ids) => ids.filter((id) => id !== book.id))
      showToast(`Returned "${book.title}"`, 'info')
    } else {
      setBorrowedIds((ids) => [...ids, book.id])
      showToast(`Borrowed "${book.title}" — added to your shelf`)
    }
  }

  const toggleReadingList = (book: Book) => {
    if (readingListIds.includes(book.id)) {
      setReadingListIds((ids) => ids.filter((id) => id !== book.id))
      showToast(`Removed "${book.title}" from reading list`, 'info')
    } else {
      setReadingListIds((ids) => [...ids, book.id])
      showToast(`Added "${book.title}" to reading list`)
    }
  }

  const addReview = (bookId: string, review: Omit<Review, 'id'>) => {
    setReviews((prev) => ({
      ...prev,
      [bookId]: [{ ...review, id: crypto.randomUUID() }, ...(prev[bookId] ?? [])],
    }))
    showToast(`Thanks ${review.name}! Your ${review.rating}-star review was submitted.`)
  }

  const cardHandlers = {
    borrowedIds,
    readingListIds,
    reviews,
    onBorrow: toggleBorrow,
    onToggleReadingList: toggleReadingList,
    onView: (book: Book) => setSelectedBookId(book.id),
  }

  return (
    <section id="library" aria-labelledby="library-heading" className="border-b border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-16 sm:px-6 md:py-20">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="flex max-w-2xl flex-col gap-2">
            <p className="font-mono text-sm text-primary">04 / React SPA Demo</p>
            <h2 id="library-heading" className="flex items-center gap-3 text-3xl font-bold tracking-tight sm:text-4xl">
              <Library className="size-8 text-primary" aria-hidden="true" />
              E-Library & Academic Hub
            </h2>
            <p className="text-pretty leading-relaxed text-muted-foreground">
              A fully interactive single-page application built with React functional components, props and{' '}
              <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">useState</code>. Search, filter,
              borrow, review and build your reading list — all without a page reload.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            className="relative inline-flex w-fit items-center gap-2 rounded-md border border-border bg-card px-4 py-2.5 text-sm font-medium shadow-sm transition-colors hover:bg-muted"
          >
            <BookMarked className="size-4" aria-hidden="true" />
            Reading List
            <span
              aria-label={`${readingListIds.length} books in reading list`}
              className="flex min-w-6 items-center justify-center rounded-full bg-primary px-1.5 py-0.5 font-mono text-xs text-primary-foreground"
            >
              {readingListIds.length}
            </span>
          </button>
        </div>

        <div className="flex flex-col gap-6 rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-6">
          <LibraryTabs activeTab={activeTab} onChange={setActiveTab} borrowedCount={borrowedIds.length} />

          {activeTab === 'all' && (
            <div className="flex flex-col gap-6">
              <LibraryToolbar
                query={query}
                onQueryChange={setQuery}
                category={category}
                onCategoryChange={setCategory}
                resultCount={filteredBooks.length}
              />
              <BookGrid
                books={filteredBooks}
                emptyMessage="No books match your search. Try a different keyword or category."
                {...cardHandlers}
              />
            </div>
          )}

          {activeTab === 'borrowed' && (
            <BookGrid
              books={borrowedBooks}
              emptyMessage="Your shelf is empty. Borrow a book from the All Books tab to see it here."
              {...cardHandlers}
            />
          )}

          {activeTab === 'resources' && <AcademicResources onAccess={(title) => showToast(`Opening "${title}"`, 'info')} />}
        </div>
      </div>

      <BookDetailsModal
        book={selectedBook}
        reviews={selectedBook ? (reviews[selectedBook.id] ?? []) : []}
        isBorrowed={selectedBook ? borrowedIds.includes(selectedBook.id) : false}
        inReadingList={selectedBook ? readingListIds.includes(selectedBook.id) : false}
        onClose={() => setSelectedBookId(null)}
        onBorrow={toggleBorrow}
        onToggleReadingList={toggleReadingList}
        onSubmitReview={addReview}
      />

      <ReadingListDrawer
        open={drawerOpen}
        books={readingListBooks}
        borrowedIds={borrowedIds}
        onClose={() => setDrawerOpen(false)}
        onRemove={toggleReadingList}
        onBorrow={toggleBorrow}
      />

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </section>
  )
}
