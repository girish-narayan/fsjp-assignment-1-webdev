'use client'

import { BookMarked, BookOpen, Check, Trash2, X } from 'lucide-react'
import type { Book } from './library-data'

type ReadingListDrawerProps = {
  open: boolean
  books: Book[]
  borrowedIds: string[]
  onClose: () => void
  onRemove: (book: Book) => void
  onBorrow: (book: Book) => void
}

export function ReadingListDrawer({ open, books, borrowedIds, onClose, onRemove, onBorrow }: ReadingListDrawerProps) {
  if (!open) return null

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-foreground/50 backdrop-blur-sm animate-in fade-in"
      onClick={onClose}
      onKeyDown={(e) => e.key === 'Escape' && onClose()}
    >
      <aside
        role="dialog"
        aria-modal="true"
        aria-labelledby="reading-list-title"
        onClick={(e) => e.stopPropagation()}
        className="flex h-full w-full max-w-sm flex-col border-l border-border bg-card shadow-xl animate-in slide-in-from-right"
      >
        <header className="flex items-center justify-between border-b border-border px-5 py-4">
          <h3 id="reading-list-title" className="flex items-center gap-2 font-semibold">
            <BookMarked className="size-5 text-primary" aria-hidden="true" />
            My Reading List
            <span className="rounded-full bg-primary px-2 py-0.5 font-mono text-xs text-primary-foreground">{books.length}</span>
          </h3>
          <button
            type="button"
            onClick={onClose}
            autoFocus
            aria-label="Close reading list"
            className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        </header>

        {books.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <BookMarked className="size-10 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              Your reading list is empty. Use the bookmark button on any book to save it here.
            </p>
          </div>
        ) : (
          <ul className="flex flex-1 flex-col gap-3 overflow-y-auto p-5">
            {books.map((book) => {
              const borrowed = borrowedIds.includes(book.id)
              return (
                <li key={book.id} className="flex gap-3 rounded-lg border border-border p-3">
                  <span className="flex h-16 w-12 shrink-0 items-center justify-center rounded bg-primary text-primary-foreground">
                    <BookOpen className="size-5" aria-hidden="true" />
                  </span>
                  <div className="flex min-w-0 flex-1 flex-col gap-1">
                    <p className="truncate text-sm font-semibold">{book.title}</p>
                    <p className="truncate text-xs text-muted-foreground">{book.author}</p>
                    <div className="mt-1 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onBorrow(book)}
                        disabled={borrowed}
                        className="inline-flex items-center gap-1 rounded bg-primary px-2 py-1 text-[11px] font-medium text-primary-foreground disabled:bg-success disabled:text-success-foreground"
                      >
                        {borrowed ? <Check className="size-3" aria-hidden="true" /> : null}
                        {borrowed ? 'Borrowed' : 'Borrow'}
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemove(book)}
                        aria-label={`Remove ${book.title} from reading list`}
                        className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-destructive"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    </div>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </aside>
    </div>
  )
}
