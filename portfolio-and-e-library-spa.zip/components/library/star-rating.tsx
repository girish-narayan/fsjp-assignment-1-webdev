import { Star } from 'lucide-react'
import type { Book, Review } from './library-data'

export function averageRating(book: Book, reviews: Review[]) {
  const total = book.rating + reviews.reduce((sum, review) => sum + review.rating, 0)
  return Math.round((total / (reviews.length + 1)) * 10) / 10
}

export function StarRating({ value, size = 'sm' }: { value: number; size?: 'sm' | 'md' }) {
  const iconSize = size === 'sm' ? 'size-3.5' : 'size-4'
  return (
    <span className="flex items-center gap-1" aria-label={`Rated ${value} out of 5`}>
      <span className="flex" aria-hidden="true">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`${iconSize} ${star <= Math.round(value) ? 'fill-warning text-warning' : 'text-muted-foreground/40'}`}
          />
        ))}
      </span>
      <span className="font-mono text-xs text-muted-foreground">{value.toFixed(1)}</span>
    </span>
  )
}
