export const CATEGORIES = ['Computer Science', 'Data Science', 'Mathematics', 'Web Development'] as const
export type Category = (typeof CATEGORIES)[number]

export type Book = {
  id: string
  title: string
  author: string
  category: Category
  rating: number
  year: number
  pages: number
  description: string
}

export type Review = {
  id: string
  name: string
  rating: number
  comment: string
}

export type LibraryTab = 'all' | 'borrowed' | 'resources'

export const BOOKS: Book[] = [
  {
    id: 'clrs',
    title: 'Introduction to Algorithms',
    author: 'Cormen, Leiserson, Rivest & Stein',
    category: 'Computer Science',
    rating: 4.7,
    year: 2022,
    pages: 1312,
    description:
      'The definitive reference on algorithms — sorting, graph algorithms, dynamic programming and NP-completeness, explained with rigorous proofs and pseudocode.',
  },
  {
    id: 'effective-java',
    title: 'Effective Java',
    author: 'Joshua Bloch',
    category: 'Computer Science',
    rating: 4.8,
    year: 2018,
    pages: 412,
    description:
      '90 best-practice items for writing robust, maintainable Java — covering generics, lambdas, streams, concurrency and API design.',
  },
  {
    id: 'clean-code',
    title: 'Clean Code',
    author: 'Robert C. Martin',
    category: 'Computer Science',
    rating: 4.4,
    year: 2008,
    pages: 464,
    description:
      'A handbook of agile software craftsmanship focused on writing readable, testable code through meaningful naming, small functions and refactoring.',
  },
  {
    id: 'python-ds',
    title: 'Python for Data Analysis',
    author: 'Wes McKinney',
    category: 'Data Science',
    rating: 4.5,
    year: 2022,
    pages: 579,
    description:
      'Hands-on guide to data wrangling with pandas, NumPy and Jupyter, written by the creator of pandas.',
  },
  {
    id: 'hands-on-ml',
    title: 'Hands-On Machine Learning',
    author: 'Aurélien Géron',
    category: 'Data Science',
    rating: 4.8,
    year: 2022,
    pages: 850,
    description:
      'Practical machine learning and deep learning with Scikit-Learn, Keras and TensorFlow, from linear regression to neural networks.',
  },
  {
    id: 'stat-learning',
    title: 'An Introduction to Statistical Learning',
    author: 'James, Witten, Hastie & Tibshirani',
    category: 'Data Science',
    rating: 4.6,
    year: 2021,
    pages: 607,
    description:
      'An accessible overview of statistical learning methods — regression, classification, resampling, tree-based methods and SVMs.',
  },
  {
    id: 'discrete-math',
    title: 'Discrete Mathematics and Its Applications',
    author: 'Kenneth H. Rosen',
    category: 'Mathematics',
    rating: 4.3,
    year: 2018,
    pages: 1120,
    description:
      'Covers logic, sets, combinatorics, graph theory and trees — the mathematical foundation for computer science.',
  },
  {
    id: 'linear-algebra',
    title: 'Linear Algebra Done Right',
    author: 'Sheldon Axler',
    category: 'Mathematics',
    rating: 4.5,
    year: 2023,
    pages: 390,
    description:
      'A determinant-free approach to linear algebra focusing on vector spaces, linear maps and eigenvalues.',
  },
  {
    id: 'eloquent-js',
    title: 'Eloquent JavaScript',
    author: 'Marijn Haverbeke',
    category: 'Web Development',
    rating: 4.4,
    year: 2024,
    pages: 456,
    description:
      'A modern introduction to programming with JavaScript, covering the language, the browser and Node.js through engaging exercises.',
  },
  {
    id: 'learning-react',
    title: 'Learning React',
    author: 'Eve Porcello & Alex Banks',
    category: 'Web Development',
    rating: 4.3,
    year: 2020,
    pages: 310,
    description:
      'Functional web development with React — components, hooks, state management, routing and testing.',
  },
  {
    id: 'css-definitive',
    title: 'CSS: The Definitive Guide',
    author: 'Eric Meyer & Estelle Weyl',
    category: 'Web Development',
    rating: 4.5,
    year: 2023,
    pages: 1126,
    description:
      'An in-depth reference for modern CSS: selectors, cascade, flexbox, grid, transforms, animations and more.',
  },
]

export type AcademicResource = {
  title: string
  type: 'Notes' | 'Question Paper' | 'Video Lecture' | 'Lab Manual'
  subject: string
  description: string
}

export const ACADEMIC_RESOURCES: AcademicResource[] = [
  {
    title: 'FSJP Lab Manual — Experiments 1–10',
    type: 'Lab Manual',
    subject: 'Full Stack Java Practicals',
    description: 'Step-by-step practicals covering HTML, CSS, Bootstrap, JavaScript and React.',
  },
  {
    title: 'Data Structures Unit-wise Notes',
    type: 'Notes',
    subject: 'Computer Science',
    description: 'Concise notes on stacks, queues, trees, graphs and hashing with solved examples.',
  },
  {
    title: 'Engineering Mathematics III — Past Papers',
    type: 'Question Paper',
    subject: 'Mathematics',
    description: 'Previous university question papers (2019–2024) with marking schemes.',
  },
  {
    title: 'React Hooks Deep Dive',
    type: 'Video Lecture',
    subject: 'Web Development',
    description: 'A lecture series on useState, useEffect, custom hooks and component composition.',
  },
  {
    title: 'Intro to Pandas & NumPy',
    type: 'Video Lecture',
    subject: 'Data Science',
    description: 'Hands-on sessions on data cleaning, aggregation and visualisation in Python.',
  },
  {
    title: 'DBMS Viva Question Bank',
    type: 'Notes',
    subject: 'Computer Science',
    description: 'Frequently asked viva questions on normalisation, SQL joins and transactions.',
  },
]

export const CATEGORY_STYLES: Record<Category, string> = {
  'Computer Science': 'bg-primary/10 text-primary',
  'Data Science': 'bg-success/15 text-success',
  Mathematics: 'bg-warning/20 text-foreground',
  'Web Development': 'bg-destructive/10 text-destructive',
}
