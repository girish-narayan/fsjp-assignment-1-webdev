import { BookmarkCheck, BookmarkPlus, BookOpen, Undo2 } from 'lucide-react'
import { CATEGORY_STYLES, type Book } from './library-data'
import { StarRating } from './star-rating'

export type BookCardProps = {
  book: Book
  rating: number
  isBorrowed: boolean
  inReadingList: boolean
  onBorrow: (book: Book) => void
  onToggleReadingList: (book: Book) => void
  onView: (book: Book) => void
}

export function BookCover({ book }: { book: Book }) {
  return (
    <div className="relative flex aspect-[3/4] flex-col justify-between overflow-hidden rounded-md bg-primary p-3 text-primary-foreground">
      <span className="absolute inset-y-0 left-0 w-2 bg-foreground/20" aria-hidden="true" />
      <span className="pl-2 font-mono text-[10px] uppercase tracking-wider opacity-80">{book.category}</span>
      <span className="pl-2 text-balance text-sm font-semibold leading-snug">{book.title}</span>
      <span className="pl-2 text-[10px] opacity-80">{book.year}</span>
    </div>
  )
}

export function BookCard({ book, rating, isBorrowed, inReadingList, onBorrow, onToggleReadingList, onView }: BookCardProps) {
  return (
    <article className="flex flex-col gap-3 rounded-xl border border-border bg-background p-4 transition-shadow hover:shadow-md">
      <button
        type="button"
        onClick={() => onView(book)}
        aria-label={`View details for ${book.title}`}
        className="rounded-md text-left focus-visible:ring-2 focus-visible:ring-ring"
      >
        <BookCover book={book} />
      </button>

      <div className="flex flex-1 flex-col gap-1.5">
        <span className={`w-fit rounded-full px-2 py-0.5 text-[10px] font-medium ${CATEGORY_STYLES[book.category]}`}>
          {book.category}
        </span>
        <h3 className="text-sm font-semibold leading-snug">
          <button type="button" onClick={() => onView(book)} className="text-left hover:text-primary">
            {book.title}
          </button>
        </h3>
        <p className="text-xs text-muted-foreground">{book.author}</p>
        <StarRating value={rating} />
      </div>

      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => onBorrow(book)}
          className={`inline-flex flex-1 items-center justify-center gap-1.5 rounded-md px-3 py-2 text-xs font-medium transition-opacity hover:opacity-90 ${
            isBorrowed ? 'bg-secondary text-secondary-foreground' : 'bg-primary text-primary-foreground'
          }`}
        >
          {isBorrowed ? <Undo2 className="size-3.5" aria-hidden="true" /> : <BookOpen className="size-3.5" aria-hidden="true" />}
          {isBorrowed ? 'Return' : 'Borrow / Read Now'}
        </button>
        <button
          type="button"
          onClick={() => onToggleReadingList(book)}
          aria-pressed={inReadingList}
          aria-label={inReadingList ? `Remove ${book.title} from reading list` : `Add ${book.title} to reading list`}
          title={inReadingList ? 'Remove from Reading List' : 'Add to Reading List'}
          className={`flex size-8 items-center justify-center rounded-md border transition-colors ${
            inReadingList ? 'border-primary bg-accent text-accent-foreground' : 'border-border hover:bg-muted'
          }`}
        >
          {inReadingList ? <BookmarkCheck className="size-4" /> : <BookmarkPlus className="size-4" />}
        </button>
      </div>
    </article>
  )
}
