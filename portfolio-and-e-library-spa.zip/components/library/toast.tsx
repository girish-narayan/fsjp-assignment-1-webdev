'use client'

import { useEffect, useEffectEvent } from 'react'
import { CheckCircle2, Info, X } from 'lucide-react'

export type ToastMessage = { id: number; message: string; tone: 'success' | 'info' }

type ToastProps = {
  toast: ToastMessage | null
  onDismiss: () => void
}

export function Toast({ toast, onDismiss }: ToastProps) {
  const dismiss = useEffectEvent(onDismiss)
  const toastId = toast?.id

  useEffect(() => {
    if (toastId === undefined) return
    const timer = setTimeout(dismiss, 3200)
    return () => clearTimeout(timer)
  }, [toastId])

  return (
    <div aria-live="polite" className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[calc(100%-2rem)] max-w-sm justify-end">
      {toast && (
        <div
          key={toast.id}
          role="status"
          className="pointer-events-auto flex w-full items-start gap-3 rounded-lg border border-border bg-card p-4 shadow-lg animate-in slide-in-from-bottom-2 fade-in"
        >
          {toast.tone === 'success' ? (
            <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-success" aria-hidden="true" />
          ) : (
            <Info className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
          )}
          <p className="flex-1 text-sm">{toast.message}</p>
          <button
            type="button"
            onClick={onDismiss}
            aria-label="Dismiss notification"
            className="rounded p-0.5 text-muted-foreground hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        </div>
      )}
    </div>
  )
}
