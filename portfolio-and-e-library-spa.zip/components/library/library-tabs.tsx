import { BookCopy, GraduationCap, Library } from 'lucide-react'
import type { LibraryTab } from './library-data'

type LibraryTabsProps = {
  activeTab: LibraryTab
  onChange: (tab: LibraryTab) => void
  borrowedCount: number
}

export function LibraryTabs({ activeTab, onChange, borrowedCount }: LibraryTabsProps) {
  const tabs = [
    { id: 'all' as const, label: 'All Books', icon: Library },
    { id: 'borrowed' as const, label: 'My Borrowed Shelf', icon: BookCopy, count: borrowedCount },
    { id: 'resources' as const, label: 'Academic Resources', icon: GraduationCap },
  ]

  return (
    <div role="tablist" aria-label="Library views" className="flex gap-1 overflow-x-auto rounded-lg bg-muted p-1">
      {tabs.map(({ id, label, icon: Icon, count }) => {
        const active = activeTab === id
        return (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(id)}
            className={`flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium transition-colors ${
              active ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon className="size-4" aria-hidden="true" />
            {label}
            {count !== undefined && (
              <span className="rounded-full bg-primary px-1.5 py-0.5 font-mono text-[10px] leading-none text-primary-foreground">
                {count}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}
