import { ClipboardList, FileText, FlaskConical, PlayCircle, type LucideIcon } from 'lucide-react'
import { ACADEMIC_RESOURCES, type AcademicResource } from './library-data'

const TYPE_ICONS: Record<AcademicResource['type'], LucideIcon> = {
  Notes: FileText,
  'Question Paper': ClipboardList,
  'Video Lecture': PlayCircle,
  'Lab Manual': FlaskConical,
}

function ResourceCard({ resource, onAccess }: { resource: AcademicResource; onAccess: (title: string) => void }) {
  const Icon = TYPE_ICONS[resource.type]
  return (
    <article className="flex gap-4 rounded-xl border border-border bg-background p-4">
      <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground">
        <Icon className="size-5" aria-hidden="true" />
      </span>
      <div className="flex flex-1 flex-col gap-1.5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-[10px] uppercase tracking-wider text-primary">{resource.type}</span>
          <span className="text-[10px] text-muted-foreground">{'· '}{resource.subject}</span>
        </div>
        <h3 className="text-sm font-semibold">{resource.title}</h3>
        <p className="text-xs leading-relaxed text-muted-foreground">{resource.description}</p>
        <button
          type="button"
          onClick={() => onAccess(resource.title)}
          className="mt-1 w-fit text-xs font-medium text-primary hover:underline"
        >
          {resource.type === 'Video Lecture' ? 'Watch now' : 'Open resource'}
          {' →'}
        </button>
      </div>
    </article>
  )
}

export function AcademicResources({ onAccess }: { onAccess: (title: string) => void }) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {ACADEMIC_RESOURCES.map((resource) => (
        <ResourceCard key={resource.title} resource={resource} onAccess={onAccess} />
      ))}
    </div>
  )
}
