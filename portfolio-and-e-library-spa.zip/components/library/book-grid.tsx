import { BookX } from 'lucide-react'
import type { Book, Review } from './library-data'
import { BookCard } from './book-card'
import { averageRating } from './star-rating'

type BookGridProps = {
  books: Book[]
  emptyMessage: string
  borrowedIds: string[]
  readingListIds: string[]
  reviews: Record<string, Review[]>
  onBorrow: (book: Book) => void
  onToggleReadingList: (book: Book) => void
  onView: (book: Book) => void
}

export function BookGrid({ books, emptyMessage, borrowedIds, readingListIds, reviews, ...handlers }: BookGridProps) {
  if (books.length === 0) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-border px-6 py-16 text-center">
        <BookX className="size-10 text-muted-foreground" aria-hidden="true" />
        <p className="max-w-sm text-sm text-muted-foreground">{emptyMessage}</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
      {books.map((book) => (
        <BookCard
          key={book.id}
          book={book}
          rating={averageRating(book, reviews[book.id] ?? [])}
          isBorrowed={borrowedIds.includes(book.id)}
          inReadingList={readingListIds.includes(book.id)}
          {...handlers}
        />
      ))}
    </div>
  )
}
