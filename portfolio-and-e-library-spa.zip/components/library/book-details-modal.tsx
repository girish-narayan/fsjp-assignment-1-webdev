'use client'

import { BookmarkCheck, BookmarkPlus, BookOpen, Undo2, X } from 'lucide-react'
import { CATEGORY_STYLES, type Book, type Review } from './library-data'
import { BookCover } from './book-card'
import { ReviewForm } from './review-form'
import { StarRating, averageRating } from './star-rating'

type BookDetailsModalProps = {
  book: Book | null
  reviews: Review[]
  isBorrowed: boolean
  inReadingList: boolean
  onClose: () => void
  onBorrow: (book: Book) => void
  onToggleReadingList: (book: Book) => void
  onSubmitReview: (bookId: string, review: Omit<Review, 'id'>) => void
}

export function BookDetailsModal({
  book,
  reviews,
  isBorrowed,
  inReadingList,
  onClose,
  onBorrow,
  onToggleReadingList,
  onSubmitReview,
}: BookDetailsModalProps) {
  if (!book) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/50 p-0 backdrop-blur-sm animate-in fade-in sm:items-center sm:p-4"
      onClick={onClose}
      onKeyDown={(e) => e.key === 'Escape' && onClose()}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="book-modal-title"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl border border-border bg-card shadow-xl animate-in slide-in-from-bottom-4 sm:rounded-2xl"
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <p className="font-mono text-xs text-muted-foreground">Book details</p>
          <button
            type="button"
            onClick={onClose}
            autoFocus
            aria-label="Close book details"
            className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="flex flex-col gap-6 p-5 sm:p-6">
          <div className="grid gap-6 sm:grid-cols-[160px_1fr]">
            <div className="mx-auto w-36 sm:w-full">
              <BookCover book={book} />
            </div>
            <div className="flex flex-col gap-3">
              <span className={`w-fit rounded-full px-2 py-0.5 text-xs font-medium ${CATEGORY_STYLES[book.category]}`}>
                {book.category}
              </span>
              <h3 id="book-modal-title" className="text-balance text-2xl font-bold tracking-tight">
                {book.title}
              </h3>
              <p className="text-sm text-muted-foreground">by {book.author}</p>
              <StarRating value={averageRating(book, reviews)} size="md" />
              <p className="text-sm leading-relaxed">{book.description}</p>
              <dl className="flex gap-6 font-mono text-xs text-muted-foreground">
                <div>
                  <dt className="sr-only">Published</dt>
                  <dd>Published {book.year}</dd>
                </div>
                <div>
                  <dt className="sr-only">Pages</dt>
                  <dd>{book.pages} pages</dd>
                </div>
              </dl>
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => onBorrow(book)}
                  className={`inline-flex items-center gap-1.5 rounded-md px-4 py-2 text-sm font-medium transition-opacity hover:opacity-90 ${
                    isBorrowed ? 'bg-secondary text-secondary-foreground' : 'bg-primary text-primary-foreground'
                  }`}
                >
                  {isBorrowed ? <Undo2 className="size-4" aria-hidden="true" /> : <BookOpen className="size-4" aria-hidden="true" />}
                  {isBorrowed ? 'Return Book' : 'Borrow / Read Now'}
                </button>
                <button
                  type="button"
                  onClick={() => onToggleReadingList(book)}
                  className="inline-flex items-center gap-1.5 rounded-md border border-border px-4 py-2 text-sm font-medium hover:bg-muted"
                >
                  {inReadingList ? <BookmarkCheck className="size-4" aria-hidden="true" /> : <BookmarkPlus className="size-4" aria-hidden="true" />}
                  {inReadingList ? 'In Reading List' : 'Add to Reading List'}
                </button>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <h4 className="text-sm font-semibold">Reviews ({reviews.length})</h4>
            {reviews.length === 0 ? (
              <p className="text-sm text-muted-foreground">No reviews yet — be the first to share your thoughts.</p>
            ) : (
              <ul className="flex flex-col gap-2">
                {reviews.map((review) => (
                  <li key={review.id} className="rounded-lg border border-border p-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium">{review.name}</span>
                      <StarRating value={review.rating} />
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{review.comment}</p>
                  </li>
                ))}
              </ul>
            )}
            <ReviewForm key={book.id} onSubmit={(review) => onSubmitReview(book.id, review)} />
          </div>
        </div>
      </div>
    </div>
  )
}
