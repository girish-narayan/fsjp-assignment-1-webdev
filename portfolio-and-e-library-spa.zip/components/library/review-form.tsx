'use client'

import { useState, type FormEvent } from 'react'
import { Star } from 'lucide-react'
import type { Review } from './library-data'

type ReviewFormProps = {
  onSubmit: (review: Omit<Review, 'id'>) => void
}

export function ReviewForm({ onSubmit }: ReviewFormProps) {
  const [name, setName] = useState('')
  const [rating, setRating] = useState(0)
  const [hovered, setHovered] = useState(0)
  const [comment, setComment] = useState('')
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!name.trim()) return setError('Please enter your name.')
    if (rating === 0) return setError('Please select a star rating.')
    if (comment.trim().length < 5) return setError('Review must be at least 5 characters.')
    onSubmit({ name: name.trim(), rating, comment: comment.trim() })
    setName('')
    setRating(0)
    setComment('')
    setError(null)
  }

  const displayRating = hovered || rating

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-3 rounded-lg border border-border bg-muted/50 p-4">
      <h4 className="text-sm font-semibold">Write a review</h4>

      <fieldset className="flex items-center gap-3">
        <legend className="sr-only">Your rating</legend>
        <div className="flex" onMouseLeave={() => setHovered(0)}>
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              aria-label={`${star} star${star > 1 ? 's' : ''}`}
              aria-pressed={rating === star}
              onClick={() => setRating(star)}
              onMouseEnter={() => setHovered(star)}
              className="p-0.5"
            >
              <Star
                className={`size-6 transition-colors ${star <= displayRating ? 'fill-warning text-warning' : 'text-muted-foreground/40'}`}
                aria-hidden="true"
              />
            </button>
          ))}
        </div>
        <span className="font-mono text-xs text-muted-foreground">{rating ? `${rating}/5` : 'Select rating'}</span>
      </fieldset>

      <label htmlFor="review-name" className="sr-only">
        Your name
      </label>
      <input
        id="review-name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Your name"
        className="rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
      />
      <label htmlFor="review-comment" className="sr-only">
        Your review
      </label>
      <textarea
        id="review-comment"
        rows={3}
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="What did you think of this book?"
        className="resize-y rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
      />
      {error && (
        <p role="alert" className="text-xs text-destructive">
          {error}
        </p>
      )}
      <button
        type="submit"
        className="w-fit rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
      >
        Submit Review
      </button>
    </form>
  )
}
