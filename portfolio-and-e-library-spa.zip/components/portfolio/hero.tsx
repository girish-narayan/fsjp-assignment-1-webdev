import { Download, Mail, MapPin } from 'lucide-react'
import { GithubIcon, LinkedinIcon } from './brand-icons'

const SOCIAL_LINKS = [
  { href: 'https://github.com/', label: 'GitHub', icon: GithubIcon },
  { href: 'https://www.linkedin.com/', label: 'LinkedIn', icon: LinkedinIcon },
  { href: '#contact', label: 'Email', icon: Mail },
]

const STATS = [
  { value: '3+', label: 'Featured projects' },
  { value: '11', label: 'Core technologies' },
  { value: '1', label: 'React SPA shipped' },
]

export function Hero() {
  return (
    <section id="about" aria-labelledby="about-heading" className="border-b border-border">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-[1.4fr_1fr]">
        <div className="flex flex-col gap-6">
          <span className="inline-flex w-fit items-center gap-2 rounded-full border border-border bg-card px-3 py-1 font-mono text-xs text-muted-foreground">
            <span className="size-2 rounded-full bg-success" aria-hidden="true" />
            Open to internships & collaborations
          </span>

          <div className="flex flex-col gap-3">
            <p className="font-mono text-sm text-primary">{'Hello, I am'}</p>
            <h1 id="about-heading" className="text-balance text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
              Girish Narayan
            </h1>
            <p className="text-xl font-medium text-muted-foreground sm:text-2xl">
              Full-Stack / Frontend Developer
            </p>
          </div>

          <p className="max-w-xl text-pretty leading-relaxed text-muted-foreground">
            I&apos;m an engineering student at Atharva College of Engineering who enjoys turning ideas into fast,
            accessible web experiences. I work across the stack with Java, Python and JavaScript, and I love building
            interactive interfaces in React — from graph-based learning tools to data dashboards.
          </p>

          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="size-4" aria-hidden="true" />
            Mumbai, Maharashtra, India
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="/girish-narayan-resume.txt"
              download
              className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-sm transition-opacity hover:opacity-90"
            >
              <Download className="size-4" aria-hidden="true" />
              Download Resume
            </a>
            {SOCIAL_LINKS.map(({ href, label, icon: Icon }) => (
              <a
                key={label}
                href={href}
                target={href.startsWith('http') ? '_blank' : undefined}
                rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
                className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-4 py-2.5 text-sm font-medium transition-colors hover:bg-muted"
              >
                <Icon className="size-4" aria-hidden="true" />
                {label}
              </a>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center gap-6">
          <div className="relative">
            <div
              role="img"
              aria-label="Profile avatar placeholder for Girish Narayan"
              className="flex size-56 items-center justify-center rounded-full border-4 border-card bg-accent font-mono text-6xl font-bold text-accent-foreground shadow-lg ring-1 ring-border sm:size-64"
            >
              GN
            </div>
            <span className="absolute bottom-4 right-4 rounded-full bg-card px-3 py-1 font-mono text-xs shadow ring-1 ring-border">
              {'</> dev'}
            </span>
          </div>

          <dl className="grid w-full max-w-sm grid-cols-3 gap-3">
            {STATS.map((stat) => (
              <div key={stat.label} className="rounded-lg border border-border bg-card p-3 text-center">
                <dt className="sr-only">{stat.label}</dt>
                <dd className="text-2xl font-bold text-primary">{stat.value}</dd>
                <dd className="text-xs text-muted-foreground">{stat.label}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
