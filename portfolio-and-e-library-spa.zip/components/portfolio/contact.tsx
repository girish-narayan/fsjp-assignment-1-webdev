'use client'

import { useState, type FormEvent } from 'react'
import { CheckCircle2, Mail, MapPin, Send, X } from 'lucide-react'
import { SectionHeading } from './section-heading'

type FormValues = { name: string; email: string; subject: string; message: string }
type FormErrors = Partial<Record<keyof FormValues, string>>

const EMPTY_FORM: FormValues = { name: '', email: '', subject: '', message: '' }
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

function validate(values: FormValues): FormErrors {
  const errors: FormErrors = {}
  if (values.name.trim().length < 2) errors.name = 'Please enter your name (at least 2 characters).'
  if (!EMAIL_PATTERN.test(values.email.trim())) errors.email = 'Please enter a valid email address.'
  if (values.subject.trim().length < 3) errors.subject = 'Subject must be at least 3 characters.'
  if (values.message.trim().length < 10) errors.message = 'Message must be at least 10 characters.'
  return errors
}

type FieldProps = {
  id: keyof FormValues
  label: string
  value: string
  error?: string
  onChange: (id: keyof FormValues, value: string) => void
  type?: string
  multiline?: boolean
  placeholder: string
}

function Field({ id, label, value, error, onChange, type = 'text', multiline, placeholder }: FieldProps) {
  const inputClass = `w-full rounded-md border bg-background px-3 py-2 text-sm outline-none transition-shadow focus-visible:ring-2 focus-visible:ring-ring/40 ${
    error ? 'border-destructive' : 'border-input'
  }`
  const describedBy = error ? `${id}-error` : undefined
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium">
        {label}
      </label>
      {multiline ? (
        <textarea
          id={id}
          name={id}
          rows={5}
          value={value}
          placeholder={placeholder}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          onChange={(e) => onChange(id, e.target.value)}
          className={`${inputClass} resize-y`}
        />
      ) : (
        <input
          id={id}
          name={id}
          type={type}
          value={value}
          placeholder={placeholder}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          onChange={(e) => onChange(id, e.target.value)}
          className={inputClass}
        />
      )}
      {error && (
        <p id={`${id}-error`} className="text-xs text-destructive">
          {error}
        </p>
      )}
    </div>
  )
}

export function Contact() {
  const [values, setValues] = useState<FormValues>(EMPTY_FORM)
  const [errors, setErrors] = useState<FormErrors>({})
  const [submittedName, setSubmittedName] = useState<string | null>(null)

  const handleChange = (id: keyof FormValues, value: string) => {
    setValues((prev) => ({ ...prev, [id]: value }))
    if (errors[id]) setErrors((prev) => ({ ...prev, [id]: undefined }))
  }

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const nextErrors = validate(values)
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) return
    setSubmittedName(values.name.trim())
    setValues(EMPTY_FORM)
  }

  return (
    <section id="contact" aria-labelledby="contact-heading" className="bg-muted/40">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 md:py-20 lg:grid-cols-[1fr_1.4fr]">
        <div className="flex flex-col gap-6">
          <SectionHeading
            id="contact-heading"
            eyebrow="05 / Contact"
            title="Let's work together"
            description="Have a project, internship or question in mind? Send me a message and I'll get back to you."
          />
          <ul className="flex flex-col gap-3 text-sm">
            <li className="flex items-center gap-3">
              <span className="flex size-9 items-center justify-center rounded-md bg-accent text-accent-foreground">
                <Mail className="size-4" aria-hidden="true" />
              </span>
              girish.narayan@example.com
            </li>
            <li className="flex items-center gap-3">
              <span className="flex size-9 items-center justify-center rounded-md bg-accent text-accent-foreground">
                <MapPin className="size-4" aria-hidden="true" />
              </span>
              Atharva College of Engineering, Mumbai
            </li>
          </ul>
        </div>

        <div className="flex flex-col gap-4">
          {submittedName && (
            <div
              role="status"
              className="flex items-start gap-3 rounded-lg border border-success/40 bg-success/10 p-4 text-sm"
            >
              <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-success" aria-hidden="true" />
              <p className="flex-1">
                <strong className="font-semibold">Message sent successfully!</strong> Thanks, {submittedName} — Girish
                will reply to you shortly.
              </p>
              <button
                type="button"
                onClick={() => setSubmittedName(null)}
                aria-label="Dismiss success message"
                className="rounded p-0.5 text-muted-foreground hover:text-foreground"
              >
                <X className="size-4" />
              </button>
            </div>
          )}

          <form
            noValidate
            onSubmit={handleSubmit}
            className="flex flex-col gap-4 rounded-xl border border-border bg-card p-6 shadow-sm"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="name" label="Name" placeholder="Your full name" value={values.name} error={errors.name} onChange={handleChange} />
              <Field id="email" label="Email" type="email" placeholder="you@example.com" value={values.email} error={errors.email} onChange={handleChange} />
            </div>
            <Field id="subject" label="Subject" placeholder="What's this about?" value={values.subject} error={errors.subject} onChange={handleChange} />
            <Field id="message" label="Message" multiline placeholder="Write your message..." value={values.message} error={errors.message} onChange={handleChange} />
            <button
              type="submit"
              className="inline-flex w-fit items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              <Send className="size-4" aria-hidden="true" />
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  )
}
