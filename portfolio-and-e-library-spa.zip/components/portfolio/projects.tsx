import { ArrowUpRight, BarChart3, BookOpen, Network, type LucideIcon } from 'lucide-react'
import { GithubIcon as Github } from './brand-icons'
import { SectionHeading } from './section-heading'

type Project = {
  title: string
  tagline: string
  description: string
  icon: LucideIcon
  tags: string[]
  liveHref: string
  liveLabel: string
}

const PROJECTS: Project[] = [
  {
    title: 'Concept-Dependency Mapper',
    tagline: 'Graph Theory & DAG Optimization',
    description:
      'Models course topics as a directed acyclic graph, detects cycles, and computes an optimal learning order using topological sorting and longest-path analysis.',
    icon: Network,
    tags: ['Java', 'Graph Theory', 'DAG', 'Topological Sort'],
    liveHref: 'https://github.com/',
    liveLabel: 'View code',
  },
  {
    title: 'E-Library Hub',
    tagline: 'Interactive React SPA',
    description:
      'A single-page academic library with live search, category filters, a borrowing shelf, a reading-list drawer, book detail modals and review submission.',
    icon: BookOpen,
    tags: ['React.js', 'useState', 'Props', 'SPA'],
    liveHref: '#library',
    liveLabel: 'Open live demo',
  },
  {
    title: 'Student Analytics Dashboard',
    tagline: 'Performance insights',
    description:
      'Visualises attendance, grades and assignment trends for students and faculty with filterable charts and semester-wise comparisons.',
    icon: BarChart3,
    tags: ['JavaScript', 'Python', 'Charts', 'Bootstrap 5'],
    liveHref: 'https://github.com/',
    liveLabel: 'View code',
  },
]

function ProjectCard({ title, tagline, description, icon: Icon, tags, liveHref, liveLabel }: Project) {
  const isExternal = liveHref.startsWith('http')
  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-sm transition-shadow hover:shadow-md">
      <div className="flex h-36 items-center justify-center border-b border-border bg-accent">
        <Icon className="size-14 text-accent-foreground transition-transform group-hover:scale-110" aria-hidden="true" />
      </div>
      <div className="flex flex-1 flex-col gap-4 p-6">
        <div>
          <p className="font-mono text-xs text-primary">{tagline}</p>
          <h3 className="mt-1 text-lg font-semibold">{title}</h3>
        </div>
        <p className="flex-1 text-sm leading-relaxed text-muted-foreground">{description}</p>
        <ul className="flex flex-wrap gap-2" aria-label="Technologies">
          {tags.map((tag) => (
            <li key={tag} className="rounded-md border border-border px-2 py-0.5 font-mono text-xs text-muted-foreground">
              {tag}
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-2 pt-2">
          <a
            href={liveHref}
            target={isExternal ? '_blank' : undefined}
            rel={isExternal ? 'noopener noreferrer' : undefined}
            className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            {isExternal ? <Github className="size-4" aria-hidden="true" /> : null}
            {liveLabel}
            <ArrowUpRight className="size-4" aria-hidden="true" />
          </a>
        </div>
      </div>
    </article>
  )
}

export function Projects() {
  return (
    <section id="projects" aria-labelledby="projects-heading" className="border-b border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 px-4 py-16 sm:px-6 md:py-20">
        <SectionHeading
          id="projects-heading"
          eyebrow="03 / Projects"
          title="Featured projects"
          description="A selection of things I've designed and built, from algorithmic tools to interactive interfaces."
        />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {PROJECTS.map((project) => (
            <ProjectCard key={project.title} {...project} />
          ))}
        </div>
      </div>
    </section>
  )
}
