export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-2 px-4 py-8 text-center sm:px-6">
        <p className="text-sm font-medium">
          © 2024 Girish Narayan | Full Stack Java Practicals (FSJP) - Assignment 1 | Atharva College of Engineering
        </p>
        <p className="font-mono text-xs text-muted-foreground">Designed & developed solo by Girish Narayan</p>
      </div>
    </footer>
  )
}
