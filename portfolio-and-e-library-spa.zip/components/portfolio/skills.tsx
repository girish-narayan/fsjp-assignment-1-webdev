import { Code2, Layout, Wrench, type LucideIcon } from 'lucide-react'
import { SectionHeading } from './section-heading'

type Skill = { name: string; level: number }
type SkillCategory = { title: string; icon: LucideIcon; skills: Skill[] }

const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Frontend',
    icon: Layout,
    skills: [
      { name: 'HTML5', level: 92 },
      { name: 'CSS3', level: 88 },
      { name: 'Bootstrap 5', level: 85 },
      { name: 'React.js', level: 82 },
      { name: 'Tailwind CSS', level: 80 },
    ],
  },
  {
    title: 'Programming',
    icon: Code2,
    skills: [
      { name: 'Java', level: 85 },
      { name: 'Python', level: 80 },
      { name: 'JavaScript', level: 84 },
    ],
  },
  {
    title: 'Tools',
    icon: Wrench,
    skills: [
      { name: 'Git', level: 82 },
      { name: 'GitHub', level: 85 },
      { name: 'VS Code', level: 90 },
    ],
  },
]

function SkillBar({ name, level }: Skill) {
  return (
    <li className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium">{name}</span>
        <span className="font-mono text-xs text-muted-foreground">{level}%</span>
      </div>
      <div
        role="progressbar"
        aria-label={`${name} proficiency`}
        aria-valuenow={level}
        aria-valuemin={0}
        aria-valuemax={100}
        className="h-2 overflow-hidden rounded-full bg-muted"
      >
        <div className="h-full rounded-full bg-primary" style={{ width: `${level}%` }} />
      </div>
    </li>
  )
}

function SkillCard({ title, icon: Icon, skills }: SkillCategory) {
  return (
    <article className="flex flex-col gap-5 rounded-xl border border-border bg-card p-6 shadow-sm">
      <header className="flex items-center gap-3">
        <span className="flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
          <Icon className="size-5" aria-hidden="true" />
        </span>
        <div>
          <h3 className="font-semibold">{title}</h3>
          <p className="text-xs text-muted-foreground">{skills.length} skills</p>
        </div>
      </header>
      <ul className="flex flex-wrap gap-2" aria-label={`${title} badges`}>
        {skills.map((skill) => (
          <li key={skill.name} className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground">
            {skill.name}
          </li>
        ))}
      </ul>
      <ul className="flex flex-col gap-4">
        {skills.map((skill) => (
          <SkillBar key={skill.name} {...skill} />
        ))}
      </ul>
    </article>
  )
}

export function Skills() {
  return (
    <section id="skills" aria-labelledby="skills-heading" className="border-b border-border bg-muted/40">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 px-4 py-16 sm:px-6 md:py-20">
        <SectionHeading
          id="skills-heading"
          eyebrow="02 / Skills"
          title="Technical toolkit"
          description="Languages, frameworks and tools I use to design, build and ship web applications."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {SKILL_CATEGORIES.map((category) => (
            <SkillCard key={category.title} {...category} />
          ))}
        </div>
      </div>
    </section>
  )
}
